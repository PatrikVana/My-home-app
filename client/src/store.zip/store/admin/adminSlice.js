// src/store/admin/adminSlice.js
import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import * as adminService from "../../modules/admin/api/adminService";

const initialState = {
  users: [],
  pendingUsers: [],
  loading: false,
  error: null,
};

// Thunky
export const fetchPendingUsers = createAsyncThunk("admin/fetchPendingUsers", async () => {
  return await adminService.getPendingUsers();
});

export const fetchAllUsers = createAsyncThunk("admin/fetchAllUsers", async () => {
  return await adminService.getUsers();
});

export const approveUser = createAsyncThunk("admin/approveUser", async (id, { dispatch }) => {
  await adminService.approveUser(id);
  dispatch(fetchPendingUsers());
  dispatch(fetchAllUsers());
});

export const rejectUser = createAsyncThunk("admin/rejectUser", async (id, { dispatch }) => {
  await adminService.rejectUser(id);
  dispatch(fetchPendingUsers());
  dispatch(fetchAllUsers());
});

export const updateUserStatus = createAsyncThunk("admin/toggleUserStatus", async ({ id, status }, { dispatch }) => {
  await adminService.toggleUserStatus(id, status);
  dispatch(fetchAllUsers());
});

export const updateUserRole = createAsyncThunk("admin/updateUserRole", async ({ id, role }, { dispatch }) => {
  await adminService.updateUserRole(id, role);
  dispatch(fetchAllUsers());
});

export const updateUserAccess = createAsyncThunk("admin/updateUserAccess", async ({ id, access }, { dispatch }) => {
  await adminService.updateUserAccess(id, access);
  dispatch(fetchAllUsers());
});

export const deleteUser = createAsyncThunk("admin/deleteUser", async (id, { dispatch }) => {
  await adminService.deleteUser(id);
  dispatch(fetchAllUsers());
});

// Slice
const adminSlice = createSlice({
  name: "admin",
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(fetchPendingUsers.fulfilled, (state, action) => {
        state.pendingUsers = action.payload;
      })
      .addCase(fetchAllUsers.fulfilled, (state, action) => {
        state.users = action.payload;
      });
  },
});

export default adminSlice.reducer;
